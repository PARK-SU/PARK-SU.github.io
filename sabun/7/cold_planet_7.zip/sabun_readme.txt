曲URL：https://web.archive.org/web/20110625181433/http://www.geocities.jp/panda_bms/cold_planet.zip

追加音源を全て同じフォルダに入れてください。