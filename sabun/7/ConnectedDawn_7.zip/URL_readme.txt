100min Fumen Cooking!! 参加作品
http://100min.lapisbms.xyz/

曲URL：https://www.axfc.net/u/3160441
イベントURL：http://manbow.nothing.sh/event/event.cgi?action=More_def&num=3&event=91

Connected Dawn_spa.bmsと比較してズレないことを確認しました。