本体URL：http://keyc.s12.xrea.com/files/c03-worlds.rar
BGA：https://www.mediafire.com/file/z4lf71a7c2li3xz/touya_worlds_bga.zip/file

追加音源を全て同じフォルダに入れてください。
Sliced by DAC (https://fsrs.github.io/)