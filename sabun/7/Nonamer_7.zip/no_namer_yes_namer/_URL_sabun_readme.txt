本体URL：https://www.axfc.net/u/956768&key=bms
パッケージURL：https://mega.nz/folder/EpgWgJqa#7OItZfYLQxZ0X8OB19yvNQ/file/45xVQQIJ

追加音源を全て同じフォルダに入れてください。