https://darksabun.github.io/event/irbattle/
(LR2IR BATTLE event page)

本体URL 
http://otafukun.s1009.xrea.com/bms.html
[ (^^)IR（キー音アレンジ）]
推定難易度: ★★5

Point expression 
100*rate

Comment
元々の目標は上級者IRでした…