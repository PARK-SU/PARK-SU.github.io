本体URL：https://www.luzeria.net/music/xx_tamamo_ogg.zip

99_tamamo_xxx.tempと比較してズレないことを確認しました。