本体URL：https://dropbox.bms.ms/u/64302289/makino_anolog_yokochou.rar

追加音源を全て同じフォルダに入れてください。