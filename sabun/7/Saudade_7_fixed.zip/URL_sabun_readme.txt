曲URL：http://diverse.jp/dbhtml/

追加音源を全て同じフォルダに入れてください。