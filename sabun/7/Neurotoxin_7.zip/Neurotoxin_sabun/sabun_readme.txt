本体URL：https://web.archive.org/web/20120108070726/http://www7b.biglobe.ne.jp/~ssbossmix/sakuzyo_Neurotoxin_ogg.zip

追加音源を全て同じフォルダに入れてください。